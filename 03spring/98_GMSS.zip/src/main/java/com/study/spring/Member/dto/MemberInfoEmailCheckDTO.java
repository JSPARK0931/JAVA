package com.study.spring.Member.dto;

public interface MemberInfoEmailCheckDTO {
    String getUserInfoEmailCheckYn();         
}