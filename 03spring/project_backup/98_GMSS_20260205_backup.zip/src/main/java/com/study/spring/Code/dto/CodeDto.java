package com.study.spring.Code.dto;

public interface CodeDto {
    String getCode();
    String getCodeName();
}

