package com.study.spring.Member.dto;

public interface MemberInfoNicknameCheckDTO {
    String getUserInfoNicknameCheckYn();         
}