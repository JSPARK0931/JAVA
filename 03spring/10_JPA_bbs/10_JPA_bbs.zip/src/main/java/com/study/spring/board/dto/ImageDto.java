package com.study.spring.board.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ImageDto {
	private Long id;
	private Integer imageOrder;
	private String fileName;
	private String originalFileName;
}
	