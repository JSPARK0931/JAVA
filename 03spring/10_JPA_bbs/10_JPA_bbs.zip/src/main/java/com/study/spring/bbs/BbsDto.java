package com.study.spring.bbs;

import lombok.Data;

@Data
public class BbsDto {
	public Long id;
	public String name;
	public String title;
	public String content;

}
