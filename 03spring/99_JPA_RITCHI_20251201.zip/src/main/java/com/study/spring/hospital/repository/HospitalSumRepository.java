package com.study.spring.hospital.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.study.spring.hospital.dto.HospitalSumDTO;
import com.study.spring.hospital.entity.Hospital;

@Repository
public interface HospitalSumRepository extends JpaRepository<Hospital, String>{

	 @Query(value = """
	 		SELECT H.h_code AS h_code,
                    H.h_name AS h_name,
                    COUNT(*) AS review_cnt,
                    ROUND(AVG(R.r_eval_pt), 1) AS avg_eval_pt
             FROM hospital H
             JOIN h_review R ON H.h_code = R.h_code
             WHERE COALESCE(R.r_del_yn,'N') = 'N'
             GROUP BY H.h_code, H.h_name
             ORDER BY review_cnt desc, avg_eval_pt desc
             """, // SQL 위치 지정자 사용 가능
             nativeQuery = true) // <-- 네이티브 쿼리 활성화
	 List<HospitalSumDTO> findHospitalSum1();
	 
	 @Query(value = """
		 		SELECT H.h_code AS h_code, 
		 			H.h_name AS h_name, 
		 			COUNT(DISTINCT R.r_id) AS review_cnt, 
		 			ROUND(AVG(R.r_eval_pt),1) AS avg_eval_pt, 
		 			COUNT(DISTINCT C.c_id) AS comment_cnt
	 			FROM hospital H
	 			JOIN h_review R ON H.h_code = R.h_code
	 			LEFT JOIN h_comment C ON R.r_id = C.r_id
	 			WHERE COALESCE(R.r_del_yn,'N') = 'N'
	 			AND COALESCE(C.c_del_yn,'N') = 'N' 
	 			GROUP BY H.h_code, H.h_name
	 			ORDER BY REVIEW_CNT DESC,AVG_EVAL_PT DESC, COMMENT_CNT DESC
	             """, // SQL 위치 지정자 사용 가능
	             nativeQuery = true) // <-- 네이티브 쿼리 활성화
	 List<HospitalSumDTO> findHospitalSum2();
	 
	 @Query(value = """
		 		SELECT H.h_code AS h_code, 
		 			H.h_name AS h_name, 
		 			COUNT(DISTINCT R.r_id) AS review_cnt, 
		 			ROUND(AVG(R.r_eval_pt),1) AS avg_eval_pt, 
		 			COUNT(DISTINCT C.c_id) AS comment_cnt
	 			FROM hospital H
	 			JOIN h_review R ON H.h_code = R.h_code
	 			LEFT JOIN h_comment C ON R.r_id = C.r_id
	 			WHERE COALESCE(R.r_del_yn,'N') = 'N'
	 			AND COALESCE(C.c_del_yn,'N') = 'N' 
	 			GROUP BY H.h_code, H.h_name
	 			ORDER BY REVIEW_CNT DESC,AVG_EVAL_PT DESC, COMMENT_CNT DESC
	             """, // SQL 위치 지정자 사용 가능
	             nativeQuery = true) // <-- 네이티브 쿼리 활성화
	 List<HospitalSumDTO> findHospitalSumByReviewCnt();
	 
	 @Query(value = """
		 		SELECT H.h_code AS h_code, 
		 			H.h_name AS h_name, 
		 			COUNT(DISTINCT R.r_id) AS review_cnt, 
		 			ROUND(AVG(R.r_eval_pt),1) AS avg_eval_pt, 
		 			COUNT(DISTINCT C.c_id) AS comment_cnt
	 			FROM hospital H
	 			JOIN h_review R ON H.h_code = R.h_code
	 			LEFT JOIN h_comment C ON R.r_id = C.r_id
	 			WHERE COALESCE(R.r_del_yn,'N') = 'N'
	 			AND COALESCE(C.c_del_yn,'N') = 'N' 
	 			GROUP BY H.h_code, H.h_name
	 			ORDER BY AVG_EVAL_PT DESC, REVIEW_CNT DESC, COMMENT_CNT DESC
	             """, // SQL 위치 지정자 사용 가능
	             nativeQuery = true) // <-- 네이티브 쿼리 활성화
	 List<HospitalSumDTO> findHospitalSumByEvalPt();
	 
	 @Query(value = """
		 		SELECT H.h_code AS h_code, 
		 			H.h_name AS h_name, 
		 			COUNT(DISTINCT R.r_id) AS review_cnt, 
		 			ROUND(AVG(R.r_eval_pt),1) AS avg_eval_pt, 
		 			COUNT(DISTINCT C.c_id) AS comment_cnt
	 			FROM hospital H
	 			JOIN h_review R ON H.h_code = R.h_code
	 			LEFT JOIN h_comment C ON R.r_id = C.r_id
	 			WHERE COALESCE(R.r_del_yn,'N') = 'N'
	 			AND COALESCE(C.c_del_yn,'N') = 'N' 
	 			GROUP BY H.h_code, H.h_name
	 			ORDER BY COMMENT_CNT DESC, AVG_EVAL_PT DESC, REVIEW_CNT DESC 
	             """, // SQL 위치 지정자 사용 가능
	             nativeQuery = true) // <-- 네이티브 쿼리 활성화
	 List<HospitalSumDTO> findHospitalSumByCommentCnt();
	 
	 @Query(value = """
		 		SELECT H.h_code AS h_code, 
		 			H.h_name AS h_name, 
		 			COUNT(DISTINCT R.r_id) AS review_cnt, 
		 			ROUND(AVG(R.r_eval_pt),1) AS avg_eval_pt, 
		 			COUNT(DISTINCT C.c_id) AS comment_cnt
	 			FROM hospital H
	 			JOIN h_review R ON H.h_code = R.h_code
	 			LEFT JOIN h_comment C ON R.r_id = C.r_id
	 			WHERE COALESCE(R.r_del_yn,'N') = 'N'
	 			AND COALESCE(C.c_del_yn,'N') = 'N' 
	 			GROUP BY H.h_code, H.h_name
	 			ORDER BY avg_eval_pt DESC, review_cnt DESC, comment_cnt DESC
	 			LIMIT 3
	             """, // SQL 위치 지정자 사용 가능
	             nativeQuery = true) // <-- 네이티브 쿼리 활성화
	 List<HospitalSumDTO> findHospitalSumByTopList();
}
