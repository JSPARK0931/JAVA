package com.study.spring.hospital.dto;


public interface HospitalSumDTO {
	String getH_code();
	String getH_name();
	Long getReview_cnt();
	Double getAvg_eval_pt();
	Long getComment_cnt();
	
}

